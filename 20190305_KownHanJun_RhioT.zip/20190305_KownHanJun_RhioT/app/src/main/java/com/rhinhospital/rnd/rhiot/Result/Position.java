package com.rhinhospital.rnd.rhiot.Result;

public class Position {
}
