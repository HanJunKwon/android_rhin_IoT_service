package com.rhinhospital.rnd.rhiot.RetrofitAPI;

public class ExampleData {
}
