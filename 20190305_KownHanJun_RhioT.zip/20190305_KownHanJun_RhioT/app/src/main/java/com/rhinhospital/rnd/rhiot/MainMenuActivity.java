package com.rhinhospital.rnd.rhiot;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainMenuActivity extends AppCompatActivity implements View.OnClickListener {
    private final static String TAG = "MainMenuActivity";
    private Button btnPatientQRCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
        String nurse_name = pref.getString("nurse_name","");
        Log.d(TAG, nurse_name);
        ActionBar ab = getSupportActionBar();
        ab.setTitle(nurse_name);
        btnPatientQRCode = (Button)findViewById(R.id.btnPatientQR);
        btnPatientQRCode.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnPatientQR:
                Intent intent = new Intent(MainMenuActivity.this, MeasureTypeActivity.class);
                startActivity(intent);
                break;
        }
    }
}
