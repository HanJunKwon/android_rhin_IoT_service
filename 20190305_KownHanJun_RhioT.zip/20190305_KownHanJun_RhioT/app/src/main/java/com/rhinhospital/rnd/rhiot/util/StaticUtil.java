package com.rhinhospital.rnd.rhiot.util;

public interface StaticUtil {
}
